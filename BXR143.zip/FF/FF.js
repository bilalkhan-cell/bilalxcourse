if (sessionStorage.getItem("hubAccess") !== "granted") {
  location.href = "../index.html";
}

const STORAGE_KEY = "ff_rank_manager_v1";

const CS_RANKS = [
  "Bronze",
  "Silver",
  "Gold",
  "Platinum",
  "Diamond",
  "Heroic",
  "Master",
  "Grandmaster"
];

const BR_RANKS = [
  "Bronze",
  "Silver",
  "Gold",
  "Platinum",
  "Diamond",
  "Heroic",
  "Master",
  "Grandmaster"
];

const MAX_CS_STARS = 5;
const MAX_BR_POINTS = 1000;

let state = loadState();

function defaultState() {
  return {
    player: {
      uid: "7746969272",
      name: "bolo-bili"
    },
    currentCS: {
      rankIndex: 0,
      stars: 0
    },
    currentBR: {
      rankIndex: 0,
      points: 0
    },
    csHistory: [],
    brHistory: []
  };
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved || defaultState();
  } catch (e) {
    return defaultState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function goHome() {
  location.href = "index.html";
}

function formatDateTime(date) {
  return new Date(date).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function getCSTotalScore(entry) {
  return entry.rankIndex * MAX_CS_STARS + entry.stars;
}

function getBRTotalScore(entry) {
  return entry.rankIndex * MAX_BR_POINTS + entry.points;
}

function fillRankSelects() {
  const csSelect = document.getElementById("csRank");
  const brSelect = document.getElementById("brRank");

  csSelect.innerHTML = CS_RANKS.map((rank, i) => `<option value="${i}">${rank}</option>`).join("");
  brSelect.innerHTML = BR_RANKS.map((rank, i) => `<option value="${i}">${rank}</option>`).join("");

  csSelect.value = state.currentCS.rankIndex;
  brSelect.value = state.currentBR.rankIndex;

  csSelect.addEventListener("change", function () {
    state.currentCS.rankIndex = Number(this.value);
    if (state.currentCS.stars > MAX_CS_STARS) state.currentCS.stars = MAX_CS_STARS;
    saveState();
    renderAll();
  });

  brSelect.addEventListener("change", function () {
    state.currentBR.rankIndex = Number(this.value);
    if (state.currentBR.points > MAX_BR_POINTS) state.currentBR.points = MAX_BR_POINTS;
    saveState();
    renderAll();
  });
}

function changeCSStars(step) {
  let rankIndex = state.currentCS.rankIndex;
  let stars = state.currentCS.stars + step;

  if (stars > MAX_CS_STARS) {
    if (rankIndex < CS_RANKS.length - 1) {
      rankIndex++;
      stars = 0;
    } else {
      stars = MAX_CS_STARS;
    }
  }

  if (stars < 0) {
    if (rankIndex > 0) {
      rankIndex--;
      stars = MAX_CS_STARS;
    } else {
      stars = 0;
    }
  }

  state.currentCS.rankIndex = rankIndex;
  state.currentCS.stars = stars;
  saveState();
  renderAll();
}

function changeBRPoints(direction) {
  const step = Math.max(1, Number(document.getElementById("brStep").value) || 1);

  let rankIndex = state.currentBR.rankIndex;
  let points = state.currentBR.points + (direction * step);

  while (points > MAX_BR_POINTS) {
    if (rankIndex < BR_RANKS.length - 1) {
      rankIndex++;
      points -= MAX_BR_POINTS;
    } else {
      points = MAX_BR_POINTS;
      break;
    }
  }

  while (points < 0) {
    if (rankIndex > 0) {
      rankIndex--;
      points += MAX_BR_POINTS;
    } else {
      points = 0;
      break;
    }
  }

  state.currentBR.rankIndex = rankIndex;
  state.currentBR.points = points;
  saveState();
  renderAll();
}

function saveCSSession() {
  state.csHistory.push({
    date: new Date().toISOString(),
    rankIndex: state.currentCS.rankIndex,
    rank: CS_RANKS[state.currentCS.rankIndex],
    stars: state.currentCS.stars
  });

  saveState();
  renderAll();
}

function saveBRSession() {
  state.brHistory.push({
    date: new Date().toISOString(),
    rankIndex: state.currentBR.rankIndex,
    rank: BR_RANKS[state.currentBR.rankIndex],
    points: state.currentBR.points
  });

  saveState();
  renderAll();
}

function resetCS() {
  const ok = confirm("Reset current CS progress?");
  if (!ok) return;

  state.currentCS = {
    rankIndex: 0,
    stars: 0
  };

  saveState();
  renderAll();
}

function resetBR() {
  const ok = confirm("Reset current BR progress?");
  if (!ok) return;

  state.currentBR = {
    rankIndex: 0,
    points: 0
  };

  saveState();
  renderAll();
}

function renderTop() {
  document.getElementById("uidText").textContent = state.player.uid;
  document.getElementById("csSessionCount").textContent = state.csHistory.length;
  document.getElementById("brSessionCount").textContent = state.brHistory.length;
  document.getElementById("currentCSRankText").textContent = CS_RANKS[state.currentCS.rankIndex];
  document.getElementById("currentBRRankText").textContent = BR_RANKS[state.currentBR.rankIndex];
  document.getElementById("csStarsText").textContent = state.currentCS.stars;
  document.getElementById("brPointsText").textContent = state.currentBR.points;

  document.getElementById("csRank").value = state.currentCS.rankIndex;
  document.getElementById("brRank").value = state.currentBR.rankIndex;
}

function renderHistory() {
  const csBody = document.getElementById("csHistoryBody");
  const brBody = document.getElementById("brHistoryBody");

  document.getElementById("csHistoryTag").textContent = `${state.csHistory.length} entries`;
  document.getElementById("brHistoryTag").textContent = `${state.brHistory.length} entries`;

  if (state.csHistory.length === 0) {
    csBody.innerHTML = `<tr><td colspan="5">No CS history yet.</td></tr>`;
  } else {
    csBody.innerHTML = state.csHistory.map((item, index) => `
      <tr>
        <td>${index + 1}</td>
        <td>${formatDateTime(item.date)}</td>
        <td>${item.rank}</td>
        <td>${item.stars}</td>
        <td>${getCSTotalScore(item)}</td>
      </tr>
    `).join("");
  }

  if (state.brHistory.length === 0) {
    brBody.innerHTML = `<tr><td colspan="5">No BR history yet.</td></tr>`;
  } else {
    brBody.innerHTML = state.brHistory.map((item, index) => `
      <tr>
        <td>${index + 1}</td>
        <td>${formatDateTime(item.date)}</td>
        <td>${item.rank}</td>
        <td>${item.points}</td>
        <td>${getBRTotalScore(item)}</td>
      </tr>
    `).join("");
  }
}

function drawChart(canvasId, history, scoreGetter, lineColor) {
  const canvas = document.getElementById(canvasId);
  const ctx = canvas.getContext("2d");

  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);

  ctx.fillStyle = "rgba(255,255,255,0.02)";
  ctx.fillRect(0, 0, w, h);

  const padding = 40;
  const graphW = w - padding * 2;
  const graphH = h - padding * 2;

  ctx.strokeStyle = "rgba(255,255,255,0.15)";
  ctx.lineWidth = 1;

  for (let i = 0; i < 5; i++) {
    const y = padding + (graphH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padding, y);
    ctx.lineTo(w - padding, y);
    ctx.stroke();
  }

  if (history.length === 0) {
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.font = "16px Arial";
    ctx.fillText("No data yet", w / 2 - 35, h / 2);
    return;
  }

  const values = history.map(scoreGetter);
  const maxValue = Math.max(...values, 1);
  const minValue = Math.min(...values, 0);
  const range = Math.max(maxValue - minValue, 1);

  ctx.strokeStyle = lineColor;
  ctx.lineWidth = 3;
  ctx.beginPath();

  values.forEach((value, index) => {
    const x = padding + (graphW / Math.max(values.length - 1, 1)) * index;
    const y = padding + graphH - ((value - minValue) / range) * graphH;

    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });

  ctx.stroke();

  values.forEach((value, index) => {
    const x = padding + (graphW / Math.max(values.length - 1, 1)) * index;
    const y = padding + graphH - ((value - minValue) / range) * graphH;

    ctx.beginPath();
    ctx.fillStyle = lineColor;
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "12px Arial";
    ctx.fillText(String(value), x - 8, y - 10);
  });
}

function renderCharts() {
  drawChart("csChart", state.csHistory, getCSTotalScore, "#60a5fa");
  drawChart("brChart", state.brHistory, getBRTotalScore, "#c084fc");
}

function copyUID() {
  const uid = state.player.uid;

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(uid).then(() => {
      alert("UID copied.");
    }).catch(() => {
      fallbackCopy(uid);
    });
  } else {
    fallbackCopy(uid);
  }
}

function fallbackCopy(text) {
  const input = document.createElement("input");
  input.value = text;
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  input.remove();
  alert("UID copied.");
}

function printPDF() {
  window.print();
}

function clearAllFFData() {
  const ok = confirm("Delete all FF manager data?");
  if (!ok) return;

  localStorage.removeItem(STORAGE_KEY);
  state = defaultState();
  saveState();
  renderAll();
}

function downloadBackup() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ff-manager-backup.json";
  a.click();
  URL.revokeObjectURL(url);
}

document.getElementById("importFile").addEventListener("change", function (e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function () {
    try {
      const imported = JSON.parse(reader.result);
      if (!imported.currentCS || !imported.currentBR || !imported.csHistory || !imported.brHistory) {
        alert("Invalid backup file.");
        return;
      }

      state = imported;
      saveState();
      renderAll();
      alert("Backup imported.");
    } catch (err) {
      alert("Invalid JSON file.");
    }
  };
  reader.readAsText(file);
});

function renderAll() {
  renderTop();
  renderHistory();
  renderCharts();
}

fillRankSelects();
renderAll();