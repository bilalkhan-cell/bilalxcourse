const CACHE_NAME = "bilxruk-hub-v1";
const FILES = [
  "index.html",
  "style.css",
  "script.js",
  "manifest.json",
  "icon.png",

  "Passbook/Passbook.html",
  "Passbook/Passbook.css",
  "Passbook/Passbook.js",

  "Milk/Milk.html",
  "Milk/Milk.css",
  "Milk/Milk.js",

  "FF/FF.html",
  "FF/FF.css",
  "FF/FF.js"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(response => response || fetch(event.request))
  );
});