if (sessionStorage.getItem("hubAccess") !== "granted") location.href = "../index.html";
const STORAGE_KEY = "milk_manager_simple_v4";

const monthPicker = document.getElementById("monthPicker");
const daysList = document.getElementById("daysList");

let milkData = loadData();

function loadData() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  } catch (e) {
    return {};
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(milkData));
}

function getTodayParts() {
  const now = new Date();
  return {
    year: now.getFullYear(),
    month: now.getMonth() + 1,
    day: now.getDate()
  };
}

function getTodayString() {
  const t = getTodayParts();
  return `${t.year}-${String(t.month).padStart(2, "0")}-${String(t.day).padStart(2, "0")}`;
}

function getCurrentMonth() {
  const t = getTodayParts();
  return `${t.year}-${String(t.month).padStart(2, "0")}`;
}

function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

function prettyDate(dateStr) {
  const date = new Date(dateStr + "T00:00:00");
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function prettyMonth(monthValue) {
  const [year, month] = monthValue.split("-").map(Number);
  return new Date(year, month - 1, 1).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric"
  });
}

function setDefaultMonth() {
  monthPicker.value = getCurrentMonth();
}

function getStatus(dateStr) {
  return milkData[dateStr] || "";
}

function setStatus(dateStr, status) {
  if (status) {
    milkData[dateStr] = status;
  } else {
    delete milkData[dateStr];
  }
  saveData();
  renderAll();
}

function isToday(dateStr) {
  return dateStr === getTodayString();
}

function getVisibleLastDay(year, month) {
  const today = getTodayParts();
  
  if (year === today.year && month === today.month) {
    return today.day;
  }
  
  if (year < today.year || (year === today.year && month < today.month)) {
    return getDaysInMonth(year, month);
  }
  
  return 0;
}

function getCardClass(dateStr, status) {
  if (status === "received") return "received";
  if (status === "not-received") return "not-received";
  if (isToday(dateStr)) return "today-pending";
  return "pending";
}

function getStatusHTML(dateStr, status) {
  if (status === "received") {
    return `<span class="status-pill status-green">Received</span>`;
  }
  if (status === "not-received") {
    return `<span class="status-pill status-red">Not Received</span>`;
  }
  if (isToday(dateStr)) {
    return `<span class="status-pill status-blue">Today</span>`;
  }
  return `<span class="status-pill status-grey">Pending</span>`;
}

function shouldShowButtons(dateStr, status) {
  return isToday(dateStr) && !status;
}

function renderSummary() {
  const monthValue = monthPicker.value;
  const [year, month] = monthValue.split("-").map(Number);
  const visibleLastDay = getVisibleLastDay(year, month);
  
  let received = 0;
  let notReceived = 0;
  let pending = 0;
  
  for (let day = 1; day <= visibleLastDay; day++) {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const status = getStatus(dateStr);
    
    if (status === "received") {
      received++;
    } else if (status === "not-received") {
      notReceived++;
    } else {
      pending++;
    }
  }
  
  document.getElementById("todayText").textContent = prettyDate(getTodayString());
  document.getElementById("receivedCount").textContent = received;
  document.getElementById("notCount").textContent = notReceived;
  document.getElementById("pendingCount").textContent = pending;
  document.getElementById("monthTitle").textContent = prettyMonth(monthValue);
  document.getElementById("monthStatusText").textContent = `${visibleLastDay} days shown`;
  
  const printMonthTitle = document.getElementById("printMonthTitle");
  const printSummaryText = document.getElementById("printSummaryText");
  
  if (printMonthTitle) {
    printMonthTitle.textContent = `${prettyMonth(monthValue)} Milk Calendar`;
  }
  
  if (printSummaryText) {
    printSummaryText.textContent = `Received: ${received} | Not Received: ${notReceived} | Pending: ${pending}`;
  }
}

function renderDays() {
  const monthValue = monthPicker.value;
  const [year, month] = monthValue.split("-").map(Number);
  const visibleLastDay = getVisibleLastDay(year, month);
  
  if (visibleLastDay === 0) {
    daysList.innerHTML = `<div class="empty">Future month selected. No dates to show yet.</div>`;
    renderPrintCalendar();
    return;
  }
  
  let html = "";
  
  for (let day = 1; day <= visibleLastDay; day++) {
    const dayStr = String(day).padStart(2, "0");
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${dayStr}`;
    const status = getStatus(dateStr);
    const dayName = new Date(dateStr + "T00:00:00").toLocaleDateString("en-IN", {
      weekday: "long"
    });
    
    const buttonsHTML = shouldShowButtons(dateStr, status) ?
      `
        <div class="right no-print">
          <button class="action-btn receive-btn" onclick="setStatus('${dateStr}','received')">Receive</button>
          <button class="action-btn not-btn" onclick="setStatus('${dateStr}','not-received')">Not</button>
        </div>
      ` :
      "";
    
    html += `
      <div class="day-item ${getCardClass(dateStr, status)}">
        <div class="left">
          <div class="date-badge">${day}</div>
          <div class="day-info">
            <h3>${prettyDate(dateStr)}</h3>
            <p>${dayName}</p>
          </div>
        </div>

        ${getStatusHTML(dateStr, status)}
        ${buttonsHTML}
      </div>
    `;
  }
  
  daysList.innerHTML = html;
  renderPrintCalendar();
}

function getPrintStatusText(dateStr, status) {
  if (status === "received") return "Received";
  if (status === "not-received") return "Not";
  if (isToday(dateStr)) return "Today";
  return "Pending";
}

function renderPrintCalendar() {
  const grid = document.getElementById("printCalendarGrid");
  if (!grid) return;
  
  const monthValue = monthPicker.value;
  const [year, month] = monthValue.split("-").map(Number);
  const visibleLastDay = getVisibleLastDay(year, month);
  
  if (visibleLastDay === 0) {
    grid.innerHTML = "";
    return;
  }
  
  const firstDayIndex = new Date(year, month - 1, 1).getDay();
  let html = "";
  
  for (let i = 0; i < firstDayIndex; i++) {
    html += `<div class="print-cell empty-cell"></div>`;
  }
  
  for (let day = 1; day <= visibleLastDay; day++) {
    const dayStr = String(day).padStart(2, "0");
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${dayStr}`;
    const status = getStatus(dateStr);
    const cellClass = getCardClass(dateStr, status);
    const statusText = getPrintStatusText(dateStr, status);
    
    html += `
      <div class="print-cell ${cellClass}">
        <div class="print-date">${day}</div>
        <div class="print-status">${statusText}</div>
      </div>
    `;
  }
  
  grid.innerHTML = html;
}

function clearMonth() {
  const ok = confirm("Clear all saved status for this month?");
  if (!ok) return;
  
  const monthValue = monthPicker.value;
  const [year, month] = monthValue.split("-").map(Number);
  const totalDays = getDaysInMonth(year, month);
  
  for (let day = 1; day <= totalDays; day++) {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    delete milkData[dateStr];
  }
  
  saveData();
  renderAll();
}

function printPDF() {
  window.print();
}

function renderAll() {
  renderSummary();
  renderDays();
}

monthPicker.addEventListener("change", renderAll);

setDefaultMonth();
renderAll();