if (sessionStorage.getItem("hubAccess") !== "granted") location.href = "../index.html";
let entries = JSON.parse(localStorage.getItem("sbiPassbookEntriesOffline")) || [];

function setTodayDate() {
  const dateInput = document.getElementById("date");
  if (!dateInput.value) {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    dateInput.value = `${yyyy}-${mm}-${dd}`;
  }
  
  const summaryMonth = document.getElementById("summaryMonth");
  if (!summaryMonth.value) {
    const now = new Date();
    const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    summaryMonth.value = ym;
  }
}

function formatMoney(value) {
  return Number(value).toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function saveEntries() {
  localStorage.setItem("sbiPassbookEntriesOffline", JSON.stringify(entries));
}

function clearForm() {
  document.getElementById("description").value = "";
  document.getElementById("type").value = "Credit";
  document.getElementById("amount").value = "";
  setTodayDate();
}

function addEntry() {
  const date = document.getElementById("date").value;
  const description = document.getElementById("description").value.trim();
  const type = document.getElementById("type").value;
  const amount = parseFloat(document.getElementById("amount").value);
  
  if (!date || !description || isNaN(amount) || amount <= 0) {
    alert("Please fill all fields correctly.");
    return;
  }
  
  entries.push({
    id: Date.now(),
    date,
    description,
    type,
    amount
  });
  
  entries.sort((a, b) => new Date(a.date) - new Date(b.date) || a.id - b.id);
  
  saveEntries();
  clearForm();
  renderAll();
}

function deleteEntry(id) {
  const ok = confirm("Delete this entry?");
  if (!ok) return;
  
  entries = entries.filter(entry => entry.id !== id);
  saveEntries();
  renderAll();
}

function clearAllEntries() {
  if (entries.length === 0) {
    alert("No entries to clear.");
    return;
  }
  
  const ok = confirm("Are you sure you want to delete all entries?");
  if (!ok) return;
  
  entries = [];
  saveEntries();
  renderAll();
}

function computeEntriesWithBalance(data) {
  let running = 0;
  
  return data.map(entry => {
    if (entry.type === "Credit") {
      running += Number(entry.amount);
    } else {
      running -= Number(entry.amount);
    }
    
    return {
      ...entry,
      balance: running
    };
  });
}

function getFilteredEntries() {
  const keyword = document.getElementById("searchInput").value.toLowerCase().trim();
  const enriched = computeEntriesWithBalance(entries);
  
  if (!keyword) return enriched;
  
  return enriched.filter(entry => {
    return (
      String(entry.date).toLowerCase().includes(keyword) ||
      String(entry.description).toLowerCase().includes(keyword) ||
      String(entry.type).toLowerCase().includes(keyword) ||
      String(entry.amount).toLowerCase().includes(keyword) ||
      String(entry.balance).toLowerCase().includes(keyword)
    );
  });
}

function renderStats() {
  let credit = 0;
  let debit = 0;
  
  entries.forEach(entry => {
    if (entry.type === "Credit") {
      credit += Number(entry.amount);
    } else {
      debit += Number(entry.amount);
    }
  });
  
  const balance = credit - debit;
  
  document.getElementById("currentBalance").textContent = formatMoney(balance);
  document.getElementById("totalCredit").textContent = formatMoney(credit);
  document.getElementById("totalDebit").textContent = formatMoney(debit);
  document.getElementById("totalEntries").textContent = entries.length;
}

function renderTable() {
  const tbody = document.getElementById("entryTableBody");
  const filtered = getFilteredEntries();
  
  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="empty">No matching transactions found.</td>
      </tr>
    `;
    return;
  }
  
  tbody.innerHTML = filtered.map((entry, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>${entry.date}</td>
      <td>${escapeHtml(entry.description)}</td>
      <td class="${entry.type === "Credit" ? "credit" : "debit"}">${entry.type}</td>
      <td>₹ ${formatMoney(entry.amount)}</td>
      <td>₹ ${formatMoney(entry.balance)}</td>
      <td class="no-print">
        <button class="danger" onclick="deleteEntry(${entry.id})">Delete</button>
      </td>
    </tr>
  `).join("");
}

function renderMonthlySummary() {
  const monthValue = document.getElementById("summaryMonth").value;
  
  let monthCredit = 0;
  let monthDebit = 0;
  let monthEntries = 0;
  
  entries.forEach(entry => {
    if (entry.date.startsWith(monthValue)) {
      monthEntries++;
      if (entry.type === "Credit") {
        monthCredit += Number(entry.amount);
      } else {
        monthDebit += Number(entry.amount);
      }
    }
  });
  
  const net = monthCredit - monthDebit;
  
  document.getElementById("monthCredit").textContent = formatMoney(monthCredit);
  document.getElementById("monthDebit").textContent = formatMoney(monthDebit);
  document.getElementById("monthNet").textContent = formatMoney(net);
  document.getElementById("monthEntries").textContent = monthEntries;
}

function exportPDFProtected() {
  const pin = prompt("Enter export password:");
  if (pin !== "BILXRUK143") {
    alert("Wrong export password.");
    return;
  }

  printPDF();
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.innerText = text;
  return div.innerHTML;
}

function renderAll() {
  renderStats();
  renderTable();
  renderMonthlySummary();
}

setTodayDate();
renderAll();