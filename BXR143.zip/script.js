const HUB_PIN = "7746969272";
const RECOVERY = {
  q1: "9321230589",
  q2: "9892323787",
  q3: "bilal_ba_13",
  q4: "Coding"
};

const lockScreen = document.getElementById("lockScreen");
const recoveryScreen = document.getElementById("recoveryScreen");
const dashboard = document.getElementById("dashboard");

const pinInput = document.getElementById("pinInput");
const unlockBtn = document.getElementById("unlockBtn");
const lockError = document.getElementById("lockError");

const showForgotBtn = document.getElementById("showForgotBtn");
const backToLoginBtn = document.getElementById("backToLoginBtn");
const recoverBtn = document.getElementById("recoverBtn");
const recoveryError = document.getElementById("recoveryError");
const recoverySuccess = document.getElementById("recoverySuccess");

const installBtn = document.getElementById("installBtn");
const lockBtn = document.getElementById("lockBtn");

let deferredPrompt = null;

function showDashboard() {
  lockScreen.classList.add("hidden");
  recoveryScreen.classList.add("hidden");
  dashboard.classList.remove("hidden");
}

function showLock() {
  dashboard.classList.add("hidden");
  recoveryScreen.classList.add("hidden");
  lockScreen.classList.remove("hidden");
}

function showRecovery() {
  lockScreen.classList.add("hidden");
  dashboard.classList.add("hidden");
  recoveryScreen.classList.remove("hidden");
}

function unlockHub() {
  const entered = pinInput.value.trim();
  
  if (entered === HUB_PIN) {
    sessionStorage.setItem("hubAccess", "granted");
    localStorage.setItem("hubWasUnlocked", "yes");
    lockError.textContent = "";
    pinInput.value = "";
    showDashboard();
    return;
  }
  
  lockError.textContent = "Wrong PIN.";
}

function verifyRecovery() {
  const a1 = document.getElementById("answer1").value.trim();
  const a2 = document.getElementById("answer2").value.trim();
  const a3 = document.getElementById("answer3").value.trim().toLowerCase();
  const a4 = document.getElementById("answer4").value.trim();
  
  const ok =
    a1 === RECOVERY.q1 &&
    a2 === RECOVERY.q2 &&
    a3 === RECOVERY.q3.toLowerCase() &&
    a4 === RECOVERY.q4;
  
  if (ok) {
    recoveryError.textContent = "";
    recoverySuccess.classList.remove("hidden");
  } else {
    recoverySuccess.classList.add("hidden");
    recoveryError.textContent = "Answers do not match.";
  }
}

function lockHub() {
  sessionStorage.removeItem("hubAccess");
  showLock();
}

function openManager(page) {
  sessionStorage.setItem("hubAccess", "granted");
  location.href = page;
}

function bindManagerButtons() {
  document.querySelectorAll(".manager-card").forEach(btn => {
    btn.addEventListener("click", () => {
      openManager(btn.dataset.target);
    });
  });
}

unlockBtn.addEventListener("click", unlockHub);
pinInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") unlockHub();
});

showForgotBtn.addEventListener("click", showRecovery);
backToLoginBtn.addEventListener("click", showLock);
recoverBtn.addEventListener("click", verifyRecovery);
lockBtn.addEventListener("click", lockHub);

bindManagerButtons();

if (sessionStorage.getItem("hubAccess") === "granted") {
  showDashboard();
} else {
  showLock();
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.hidden = false;
});

installBtn.addEventListener("click", async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  installBtn.hidden = true;
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}